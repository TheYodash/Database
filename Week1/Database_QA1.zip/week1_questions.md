# Questions

- [Questions](#questions)
  - [Is there a method to temporarily store database write queries when the database server becomes unavailable, ensuring that these queries can be executed once the server is back online?](#is-there-a-method-to-temporarily-store-database-write-queries-when-the-database-server-becomes-unavailable-ensuring-that-these-queries-can-be-executed-once-the-server-is-back-online)
  - [In fact , i don't realy understand what a dump is](#in-fact--i-dont-realy-understand-what-a-dump-is)
  - [How can I make a backup (dump) of my database? Do I need special permissions?](#how-can-i-make-a-backup-dump-of-my-database-do-i-need-special-permissions)
  - [How do I move my data to a new server? What are the steps?](#how-do-i-move-my-data-to-a-new-server-what-are-the-steps)
  - [How can I check if my backup (dump) is restored correctly?](#how-can-i-check-if-my-backup-dump-is-restored-correctly)
  - [What challenges might you face when migrating data between different database systems, and how can you address these challenges?](#what-challenges-might-you-face-when-migrating-data-between-different-database-systems-and-how-can-you-address-these-challenges)
  - [What does database scalability mean, and how can we improve the scalability of a database?](#what-does-database-scalability-mean-and-how-can-we-improve-the-scalability-of-a-database)
  - [what is the difference between mysql and mysql2 node packages](#what-is-the-difference-between-mysql-and-mysql2-node-packages)
  - [what is the best practical form way to create a new database using Node.js and MySQL?](#what-is-the-best-practical-form-way-to-create-a-new-database-using-nodejs-and-mysql)
  - [Can you explain more about PRIMARY KEY (id) and FOREIGN KEY please ?](#can-you-explain-more-about-primary-key-id-and-foreign-key-please-)
  - [how do companies handle databases or create tables, through command line or SQL admin or from the projects itself?](#how-do-companies-handle-databases-or-create-tables-through-command-line-or-sql-admin-or-from-the-projects-itself)
  - [`mysql.createPool()` creates a pool of connections that allows for handling multiple MySQL connections simultaneously, whereas `mysql.createConnection()` establishes a single MySQL connection. My question is: Can a single connection created with `mysql.createConnection()` execute multiple SQL queries at the same time?](#mysqlcreatepool-creates-a-pool-of-connections-that-allows-for-handling-multiple-mysql-connections-simultaneously-whereas-mysqlcreateconnection-establishes-a-single-mysql-connection-my-question-is-can-a-single-connection-created-with-mysqlcreateconnection-execute-multiple-sql-queries-at-the-same-time)
  - [Is it important to learn functions like ABS, CEIL, AVG, LOWER, and SUM for real-world scenarios? How frequently are they used? Could you provide a real-life example where these functions might be applicable?](#is-it-important-to-learn-functions-like-abs-ceil-avg-lower-and-sum-for-real-world-scenarios-how-frequently-are-they-used-could-you-provide-a-real-life-example-where-these-functions-might-be-applicable)


## Is there a method to temporarily store database write queries when the database server becomes unavailable, ensuring that these queries can be executed once the server is back online?

The relation between an application code and database is often a relation of [client-server](https://en.wikipedia.org/wiki/Client%E2%80%93server_model).

Your application is the client of the server. It is like in a restaurant, if the server is not available for you to make an order. That could be linked to different reasons, connections issues or issues with the database itself. In that case, your application has to implement a mechanism to wait for the server to be back on before sending the order.

How to do that? As always, it depends on the constraints of your system.

- Is it acceptable for your user to send the query and not get an immediate feedback?
- Do you have to keep the order in which queries are made ?
- For how long and how many queries are you willing to wait ?

Possible approaches:

- You directly respond to the user that there was an error and the user makes the request later
- You retry the request a certain number of time before returning an error to the user. (An observed practice is also to increase the waiting time between retries to not overload the server, this is called [Exponential Backoff](https://en.wikipedia.org/wiki/Exponential_backoff))
- You implement another storage mechanism in your application. In can be stored in memory or in a queue so your application can make the query later once the server is back on.

What when we deal with critical service?

In this case, we try to ensure [high availability](https://en.wikipedia.org/wiki/High_availability) of the Database. There are many strategies which can be put in place, like replicating the server. If one instance is done, we can contact another one.

## In fact , i don't realy understand what a dump is

If we look at [MySQL Documentation for dumps](https://dev.mysql.com/doc/refman/8.4/en/mysqldump.html). It says:

> The mysqldump client utility performs logical backups, producing a set of SQL statements that can be executed to reproduce the original database object definitions and table data.

In simple worlds, we are asking MySQL to create a file with multiple queries inside. If we execute those queries in order on another MySQL server, then it will recreate our database with the same structure and data as the previous MySQL database.

## How can I make a backup (dump) of my database? Do I need special permissions?

We go back to MySQL documentation, it says that if we only want to Dump data tables, then:

> mysqldump requires at least the `SELECT` privilege for dumped tables

The documentation also tells us which other permissions we may need if we want to dump other things.

To add a permission we can do:

```SQL
GRANT PRIVILEGE ON database.table TO 'username'@'host';
```

For example, we have the database `world`, if we want to make a dump of the table using the account `hyfuser`@`%`. We can do:

```SQL
GRANT SELECT ON world.* TO `hyfuser`@`%`;
```

## How do I move my data to a new server? What are the steps?

We can use mysqldump as documented:

```bash
mysqldump --user=hyfuser --password=hyfpassword world > dump.sql
```

We connect to mysql and create the new database were we want to restore the data:

```SQL
CREATE DATABASE IF NOT EXISTS new_world;
```

And then we can use it to restore our data in a new database:

```bash
mysql --user=hyfuser --password=hyfpassword new_world < dump.sql
```

## How can I check if my backup (dump) is restored correctly?

MySQL will tell us if any error was encountered. We can also directly query the newly created database to check that the data are present.

If can be a good reflex to check how many entries are present per table.

## What challenges might you face when migrating data between different database systems, and how can you address these challenges?

As always in IT, it depends on the situation. When migrating data, there are different things to take into considerations:

- Can we have downtime? Can we shutdown the application using the database while doing the migration?
  - If we can't have downtime, we need to check if the database technology we use have the capability to do [data synchronization](https://en.wikipedia.org/wiki/Data_synchronization) with another instance. If not, we can implement logic on the application side
  - If we can have downtime, we can shutdown the database. Create a dump of it (it is true for MySQL, other database technologies may have other methods)
- What is the size of the data we are trying to migrate?
  - If the size is important, we need to consider using [Data Compression](https://en.wikipedia.org/wiki/Data_compression). Depending on the place where server is running, this would reduce the cost of moving data.
- What is the nature of the data ?
  - If we are switching from one Database technology to another. Example [Relational Database](https://en.wikipedia.org/wiki/Relational_database) (often SQL based) to a [Document database](https://en.wikipedia.org/wiki/Document-oriented_database) (often referred to as NoSQL). We need to reshape the data using a dedicated script or tool.

## What does database scalability mean, and how can we improve the scalability of a database?

If we look at the Wikipedia page on [Database Scalability](https://en.wikipedia.org/wiki/Database_scalability) we see that multiple approaches can be used.

In simple worlds, it is the ability of the database to handle request from clients when the demand changes. We may scale down when the demand decrease or scale up when it increase.

Demand can be measured by:

- Amount of data being moved
- The volume of requests (usually per second or minute)
- The size of the requests (usually the average size per request)

Different queries may have different impacts on those dimensions. Now that we know that, how do we scale?

Again it depends on your situation. The simplest ways to scale a database are based on two dimensions:

- **Vertical (scale up)**: on the same machine, we allocate more or less resources (CPU, Memory, Disk usage, Ports, etc..). A database responding to 200 queries per second will not have the same needs as one responding to 5 queries per seconds
- **Horizontal (scale out)**: using additional machines. This is the case when we need the data to be accessible from different places or when one machine can't support the demand. It requires that the Database technology supports [data synchronization](https://en.wikipedia.org/wiki/Data_synchronization) between the different instances. **However, this approach comes with a cost which every Engineering team have to acknowledge. We must sacrifice on Availability or Consistency of the data. This is called [the CAP theorem](https://en.wikipedia.org/wiki/CAP_theorem).** For the Database module, it is not required that you understand the implications of the theorem. But being aware of its existence will help you.

If those approaches are not enough, it is also possible to use other techniques by rearranging the data themselves.

- We can [partition](https://en.wikipedia.org/wiki/Partition_(database)) data on multiple servers. Each server has only a part of the full picture
- We can do [Command Query Responsibility Segregation (CQRS)](https://en.wikipedia.org/wiki/Command_Query_Responsibility_Segregation), one instance of the database is used for writing and updating data. The data are then copied to other instances which are used to read data. Because we write only in a limited number of instances, it makes the synchronization easier.

## what is the difference between mysql and mysql2 node packages

If we go to [mysql2 repository](https://github.com/sidorares/node-mysql2), we see a section telling us about the history of the package.

> MySQL2 project is a continuation of MySQL-Native. Protocol parser code was rewritten from scratch and api changed to match popular Node MySQL. MySQL2 team is working together with Node MySQL team to factor out shared code and move it under mysqljs organization.

We can also see that the last change on [mysql](https://github.com/mysqljs/mysql) are from 2 years ago while last changes are from few weeks ago for `mysql2`.

All those information tells us that `mysql` is not maintained anymore and a new package which is maintained with better performance should be used. It also inform us that the usage of `mysql2` is close to `mysql` package.

## what is the best practical form way to create a new database using Node.js and MySQL?

In `Node.js` we can connect to a MySQL server using `mysql.createConnection()`. It is then possible to execute queries to create a database as we would do from our terminal.

Example:

```js
var mysql2 = require('mysql2');

var connection = mysql2.createConnection({
  host: "localhost",
  user: "yourusername",
  password: "yourpassword"
});

connection.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
  connection.query("CREATE DATABASE mydb", function (err, result) {
    if (err) throw err;
    console.log("Database created");
  });
});
```

## Can you explain more about PRIMARY KEY (id) and FOREIGN KEY please ?

If we look at HyF course about SQL identifiers

> The PRIMARY KEY uniquely identifies each record in a table. Primary keys must contain UNIQUE values, and cannot contain NULL values. A table can have only ONE primary key but this primary key can consist of single or multiple columns (fields).

Let's take an example. We have a table called `persons`. Each raw is about a person. For each person we have the following columns: `firstname`,`familyname`,`birthdate`,`birthplace`,`age`.

The `PRIMARY KEY` is what uniquely identifies a person in this table. There can be only one `PRIMARY KEY` but it can be composed of multiple columns. We can decide that what uniquely identiy a person is the combination of their `firstname`, `familyname` and `birthdate` (in reality it is not always true but let's assume it is OK for this example). Then the FOREIGN KEY is the `firstname`, `familyname` and `birthdate`, the database system will not allow two raw to have the same combination of those values. In SQL, we let the database know by marking each column as `PRIMARY KEY` or `PK`

Now about `FOREIGN KEY`. In my database, I also have a table called `families` with the columns `familyname`,`familyhome`. (let's imagine that two families can't have the same name). The `PRIMARY KEY` of this table is `familyname`.

We want to link each person to their respective family in the database. So we can ensure that everyone has a valid `familyname` and belong to an existing family. In the table `persons`, we can mark `familyname` as a `FOREIGN KEY` linked to the `familyname` in the `families` table. So know we now that the `familyname` of a person always correspond to a family in the `families` table.

## how do companies handle databases or create tables, through command line or SQL admin or from the projects itself?

As often in Software Engineering, it depends on the context and the company. Every management style exist, when you are a small organization with 1 or 2 developers, then managing the SQL server through the command line or SQL admin interface can work. It is also possible to do it from a git project. It depends what is best for your team to work and what meets the requirements.

A good concept to keep in mind in enterprise is **Pet vs Cattle**. It describes how you treat your computer resources.

A pet:

> The "Pets" service model describes carefully tended servers that are lovingly nurtured and given names like they were faithful family pets. Zeus, Apollo, Athena et al are well cared for.
> When they start to fail or struggle, you carefully nurse them back to health, scale them up and make them shiny and new once in a while.
> Being a mainframe, solitary service, database server or load balancer, when Zeus goes missing, everybody notices.

A cattle:

> Cattle on the other hand aren't afforded quite the same loving attention as Zeus or Apollo. This service model typically tags servers like svr01 svr02 svr03 etc much the same way cattle ear tags are applied. They are all configured pretty much identically, so that when one gets sick, you simply replace it with another one without a second thought.
> A typical use of cattle configurations would be web server arrays, search clusters, no-sql clusters, datastores and big-data clusters.
> As the adoption of bare-metal racked cattle servers either on-prem or in data centers became popular, so did the need for automation to control them.

In small organization, having a database treated as a pet is OK as long as it work for your team. On the other hand, big organization may prefer to have a cattle approach. They have to run thousands of servers and have to build farms for it.

For example, facebook can't afford to have thousands of Engineers grooming pets databases. In their case, it makes more sense to use dedicated tools and automation to farm those servers as cattle.

Those farming tool come with an initial cost that a small organization may not want to invest. In that case, database can be more uniquely managed like pets. However, having pets does not mean that you can't build automation to help you groom them!

## `mysql.createPool()` creates a pool of connections that allows for handling multiple MySQL connections simultaneously, whereas `mysql.createConnection()` establishes a single MySQL connection. My question is: Can a single connection created with `mysql.createConnection()` execute multiple SQL queries at the same time?

`mysql2` [documentation](https://sidorares.github.io/node-mysql2/docs/api-and-configurations) says that it is mostly compatible with `mysql` package. So let's have a look to [mysql documentation](https://www.npmjs.com/package/mysql#executing-queries-in-parallel). It says that:

> The MySQL protocol is sequential, this means that you need multiple connections to execute queries in parallel. You can use a Pool to manage connections, one simple approach is to create one connection per incoming http request.

The answer is No. A single connection will handle queries sequentially (in order). Which means that multiple connections are required to execute multiple SQL queries at the same time. However, running multiple queries at the same time does not guarantee us the order in which the queries will be executed.

## Is it important to learn functions like ABS, CEIL, AVG, LOWER, and SUM for real-world scenarios? How frequently are they used? Could you provide a real-life example where these functions might be applicable?

Yes it is, those function will help us manipulate data. The frequency depends on the nature of data you are working with as always.

Few examples:

- I want to compare two texts ('Hello World' and "hello world") in a none case sensitive way. I can do:

```SQL
...
WHERE LOWER('Hello World') == LOWER('hello world')
...
```

- For SUM, from [MySQL documentation](https://www.mysqltutorial.org/mysql-aggregate-functions/mysql-sum/)

This example uses the SUM() function to get the total number of items of the order details:

```SQL
SELECT 
    SUM(quantityOrdered) SalesQuantity
FROM
    orderdetails;
```

An [article with other examples](https://www.sevenmentor.com/mysql-built-in-functions-with-examples)
